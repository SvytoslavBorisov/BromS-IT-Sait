"use client";

import React from "react";
import CryptoLandingClient from "@/components/crypto-landing/CryptoLandingClient";

export default function Page() {
  return <CryptoLandingClient />;
}
