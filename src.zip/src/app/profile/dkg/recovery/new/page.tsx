import RecoveryNewPage from "@/components/profile/DKG/NewPageRecovery";
export const dynamic = "force-dynamic";
export default function Page() { return <RecoveryNewPage />; }