import DKGNewPage from "@/components/profile/DKG/NewPage";

export const dynamic = "force-dynamic";
export default function Page() {
  return <DKGNewPage />;
}