declare module 'supertest' {
  import * as supertest from 'supertest';
  export = supertest;
}