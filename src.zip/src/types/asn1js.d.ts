declare module "asn1.js" {
  // you can tighten this up later, but `any` will remove the TS errors
  const content: any;
  export = content;
}