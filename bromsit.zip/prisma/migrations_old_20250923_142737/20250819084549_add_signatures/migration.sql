/*
  Warnings:

  - You are about to drop the column `m` on the `AsymmetricKey` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE "AsymmetricKey" DROP COLUMN "m";
