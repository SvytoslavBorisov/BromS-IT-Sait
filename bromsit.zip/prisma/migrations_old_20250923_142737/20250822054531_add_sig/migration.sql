-- AlterTable
ALTER TABLE "Signatures" ADD COLUMN     "path" TEXT;
