-- AlterTable
ALTER TABLE "ShamirSession" ADD COLUMN     "title" TEXT;
