-- AlterTable
ALTER TABLE "ShamirSession" ADD COLUMN     "status" TEXT NOT NULL DEFAULT '';
