/*
  Warnings:

  - You are about to drop the column `comment` on the `RecoverySession` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE "RecoverySession" DROP COLUMN "comment";
