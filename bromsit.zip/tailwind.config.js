/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./src/app/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/components/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/pages/**/*.{js,ts,jsx,tsx,mdx}",
  ],
 theme: {
    extend: {
      typography: ({ theme }) => ({
        DEFAULT: {
          css: {
            h2: {
              fontSize: theme("fontSize.2xl"),
              fontWeight: theme("fontWeight.semibold"),
              color: theme("colors.gray.800"),
            },
            h3: {
              fontSize: theme("fontSize.xl"),
              fontWeight: theme("fontWeight.semibold"),
            },
          },
        },
      }),
    },
  },
  plugins: [],
};