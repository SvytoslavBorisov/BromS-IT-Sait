export default function Home() {
  return (
    <div className="card p-6">
      <div className="h1 mb-2">Привет!</div>
      <p className="muted">Это порт твоего Django-проекта на Next.js: модели игроков/команд, симуляция матча, генерация расписания.</p>
    </div>
  );
}
