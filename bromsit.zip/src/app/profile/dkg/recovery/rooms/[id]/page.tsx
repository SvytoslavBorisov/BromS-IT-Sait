import RecoveryRoomPage from "@/components/profile/DKG/RoomPageRecovery";
export const dynamic = "force-dynamic";
export default function Page() { return <RecoveryRoomPage />; }