"use client";

import React from "react";
import BookFlip from "./crypto/BookFlip"; // компонент с переворотом страницы

export default function Page() {
  return (
    <div>
      <BookFlip />
    </div>
  );
}
