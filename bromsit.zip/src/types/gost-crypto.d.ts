declare module 'gost-crypto' {
  const gostCrypto: any;
  export default gostCrypto;
}