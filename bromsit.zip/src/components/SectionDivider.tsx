// components/SectionDivider.tsx
"use client";

import React from "react";

export default function SectionDivider({
  flip = false,
  className = "",
}: { flip?: boolean; className?: string }) {
  const id = React.useId();

  return (
    <div
      aria-hidden
      className={[
        "relative isolate h-16 md:h-24 -mt-6 pointer-events-none bg-white",
        className,
      ].join(" ")}
    >
      {/* Белые «шторы», чтобы не было стыков с блоками сверху/снизу */}
      <div className="pointer-events-none absolute inset-x-0 top-0 h-10 md:h-12 bg-gradient-to-b from-white to-transparent z-0" />
      <div className="pointer-events-none absolute inset-x-0 bottom-0 h-10 md:h-12 bg-gradient-to-t from-white to-transparent z-0" />

      <svg
        className={`absolute inset-0 h-full w-full ${flip ? "rotate-180" : ""}`}
        viewBox="0 0 1440 160"
        preserveAspectRatio="none"
      >
        <defs>
          {/* Тень по линии волны */}
          <linearGradient id={`${id}-shadow`} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor="black" stopOpacity="0.18" />
            <stop offset="1" stopColor="black" stopOpacity="0" />
          </linearGradient>
          <filter id={`${id}-blur`} x="-20%" y="-20%" width="140%" height="140%">
            <feGaussianBlur stdDeviation="8" />
          </filter>

          {/* Едва заметный глянец */}
          <linearGradient id={`${id}-gloss`} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor="white" stopOpacity="0.9" />
            <stop offset="1" stopColor="white" stopOpacity="0.3" />
          </linearGradient>

          {/* Полупрозрачный отблеск для второго слоя */}
          <linearGradient id={`${id}-glow`} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor="white" stopOpacity="0.35" />
            <stop offset="1" stopColor="white" stopOpacity="0.0" />
          </linearGradient>

          {/* Анимация смещения по X (SVG-группа длиннее в 2× ширины) */}
          <style>
            {`
              @keyframes waveShiftDesktop {
                0%   { transform: translateX(0); }
                100% { transform: translateX(-50%); }
              }
              @keyframes waveShiftMobile {
                0%   { transform: translateX(0); }
                100% { transform: translateX(-50%); }
              }
              /* По умолчанию (мобайл): медленнее и толще линия */
              .wave-runner {
                animation: waveShiftMobile 18s linear infinite;
                will-change: transform;
              }
              /* На десктопе ускоряем */
              @media (min-width: 768px) {
                .wave-runner {
                  animation: waveShiftDesktop 14s linear infinite;
                }
              }
              /* Respect reduced motion */
              @media (prefers-reduced-motion: reduce) {
                .wave-runner { animation: none; }
              }
            `}
          </style>
        </defs>

        {/* Лента вдвое шире вьюбокса: две волны подряд, чтобы сдвиг зацикливался */}
        <g className="wave-runner" style={{ transformBox: "fill-box", transformOrigin: "center" }}>
          <g>
            {/* ТЕНЬ — мягкая, чтобы волна читалась на любом фоне */}
            <path
              d="
                M0,78 C240,140 420,20 720,78 C1020,130 1200,40 1440,92
                C1680,140 1860,20 2160,78 C2460,130 2640,40 2880,92
              "
              fill="none"
              stroke={`url(#${id}-shadow)`}
              strokeWidth="26"
              strokeLinecap="round"
              filter={`url(#${id}-blur)`}
              style={{ mixBlendMode: "multiply" }}
            />
            {/* ОСНОВНАЯ ЛИНИЯ */}
            <path
              d="
                M0,78 C240,140 420,20 720,78 C1020,130 1200,40 1440,92
                C1680,140 1860,20 2160,78 C2460,130 2640,40 2880,92
              "
              fill="none"
              stroke={`url(#${id}-gloss)`}
              strokeWidth="3"
            />
            {/* ЕЛЕ ЗАМЕТНОЕ СВЕЧЕНИЕ (вторая дорожка) */}
            <path
              d="
                M0,92 C240,152 420,32 720,92 C1020,142 1200,58 1440,110
                C1680,152 1860,32 2160,92 C2460,142 2640,58 2880,110
              "
              fill="none"
              stroke={`url(#${id}-glow)`}
              strokeWidth="12"
            />
          </g>
        </g>
      </svg>
    </div>
  );
}

