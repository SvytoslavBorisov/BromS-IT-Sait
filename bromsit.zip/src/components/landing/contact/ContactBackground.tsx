// components/contact/ContactBackground.tsx
"use client";

import React from "react";
import BackgroundGridLight from "@/components/landing/BackgroundStatic";

export default function ContactBackground() {
  return <BackgroundGridLight />;
}
