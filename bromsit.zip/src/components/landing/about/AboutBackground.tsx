// components/about/AboutBackground.tsx
"use client";

import React from "react";
import BackgroundGridLight from "@/components/landing/BackgroundStatic";

export default function AboutBackground() {
  return <BackgroundGridLight />;
}
